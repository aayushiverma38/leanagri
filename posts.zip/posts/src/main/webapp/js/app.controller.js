var postsModule = angular.module('postsApp', []);
postsModule.controller('postsController', function ($scope,$http) {
 var urlBase="https://jsonplaceholder.typicode.com";
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  $scope.commFlag=false;
  $scope.showFlag=false;
  //get all posts and display initially
 $http.get(urlBase+'/posts').
     then(function(response) {
         $scope.posts = response.data;
         // alert(data);
    });
 //view a post
 $scope.view = function(pst) {
  
   $http.get(urlBase + '/posts/' + pst.id).
    then(function(commResponse) {
    		$scope.commFlag=true;
    		$scope.comments = commResponse.data;
    		alert($scope.comments.body);
        
      });
  }
 //add a new post
 $scope.showForm = function(){$scope.showFlag=true;};
 $scope.submit = function() {
	  
	   $http.post(urlBase + '/posts/' + $scope.userId+'/' + $scope.id+'/' + $scope.title+'/'+$scope.body).
	    then(function(postResponse) {
	    	alert("Post added");
	        
	      });
	  }
 });